package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

sealed class AppDestination {
    data object Welcome : AppDestination()
    data object Login : AppDestination()
    data object SignUp : AppDestination()
    data class Session(val identifier: String, val email: String?) : AppDestination()
}

@Composable
fun GamiApp(modifier: Modifier = Modifier) {
    var currentDestination by remember { mutableStateOf<AppDestination>(AppDestination.Welcome) }

    // System Back navigation support
    if (currentDestination != AppDestination.Welcome) {
        BackHandler {
            currentDestination = AppDestination.Welcome
        }
    }

    AnimatedContent(
        targetState = currentDestination,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "GamiAppScreenTransition",
        modifier = modifier.fillMaxSize()
    ) { destination ->
        when (destination) {
            is AppDestination.Welcome -> {
                WelcomeScreen(
                    onNavigateToLogin = { currentDestination = AppDestination.Login },
                    onNavigateToSignUp = { currentDestination = AppDestination.SignUp }
                )
            }
            is AppDestination.Login -> {
                LoginScreen(
                    onNavigateBack = { currentDestination = AppDestination.Welcome },
                    onNavigateToSignUp = { currentDestination = AppDestination.SignUp },
                    onLoginSuccess = { identifier ->
                        currentDestination = AppDestination.Session(identifier, null)
                    }
                )
            }
            is AppDestination.SignUp -> {
                SignUpScreen(
                    onNavigateBack = { currentDestination = AppDestination.Welcome },
                    onNavigateToLogin = { currentDestination = AppDestination.Login },
                    onSignUpSuccess = { username, email ->
                        currentDestination = AppDestination.Session(username, email)
                    }
                )
            }
            is AppDestination.Session -> {
                SessionScreen(
                    userIdentifier = destination.identifier,
                    userEmail = destination.email,
                    onLogOut = { currentDestination = AppDestination.Welcome }
                )
            }
        }
    }
}
