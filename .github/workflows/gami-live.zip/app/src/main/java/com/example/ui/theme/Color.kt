package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GAMI LIVE Dark Palette
val GamiDarkBackground = Color(0xFF0D0C15)
val GamiDarkSurface = Color(0xFF161524)
val GamiDarkSurfaceVariant = Color(0xFF222038)
val GamiDarkBorder = Color(0xFF2E2C48)

val GamiPrimary = Color(0xFFFF2E63) // Vibrant Neon Coral/Crimson
val GamiPrimaryVariant = Color(0xFFE01B4C)
val GamiSecondary = Color(0xFF00E5FF) // Electric Cyan Accent
val GamiTertiary = Color(0xFF8B5CF6) // Royal Purple

val GamiTextPrimary = Color(0xFFF7F7FD)
val GamiTextSecondary = Color(0xFFA5A4C0)
val GamiTextMuted = Color(0xFF6E6D8A)

val GamiError = Color(0xFFFF4D4F)
val GamiSuccess = Color(0xFF00E676)

