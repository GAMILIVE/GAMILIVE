package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val GamiDarkColorScheme =
  darkColorScheme(
    primary = GamiPrimary,
    onPrimary = GamiTextPrimary,
    primaryContainer = GamiPrimaryVariant,
    onPrimaryContainer = GamiTextPrimary,
    secondary = GamiSecondary,
    onSecondary = GamiDarkBackground,
    tertiary = GamiTertiary,
    onTertiary = GamiTextPrimary,
    background = GamiDarkBackground,
    onBackground = GamiTextPrimary,
    surface = GamiDarkSurface,
    onSurface = GamiTextPrimary,
    surfaceVariant = GamiDarkSurfaceVariant,
    onSurfaceVariant = GamiTextSecondary,
    outline = GamiDarkBorder,
    error = GamiError,
    onError = GamiTextPrimary,
  )

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = GamiDarkColorScheme,
    typography = Typography,
    content = content
  )
}

